# USARE IL DATASET
Nella cartella di input ci sono 20 casi di test con i quali testare il vostro programma sulla vostra macchina. 

# COMPILARE IL CORRETTORE
g++ -o cor -O2 -Wall -std=c++0x cor.cpp

# USARE IL CORRETTORE
Passate al correttore il file di input, il corrispondente file helper (nella cartella helper) e l'output del vostro programma.
Ad esempio, se avete eseguito il vostro codice utilizzando i dati del caso 5, eseguite il seguente comando:
./cor input/input5.txt helper/helper5.txt testoutput.txt
Il correttore vi darà il punteggio associato al vostro programma.

# NOTE
Il correttore fornito con questo dataset non è in grado di correggere il testcase più grande, ma solo di dirvi se il numero di psichici è corretto.
